from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
import yaml


def load_yaml(path: str | Path) -> dict:
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f) or {}


def project_root_from_config(config_path: str | Path) -> Path:
    p = Path(config_path).resolve()
    return p.parent.parent if p.parent.name == "config" else p.parent


def resolve_paths(cfg: dict, config_path: str | Path) -> dict:
    validate_config(cfg)
    root = project_root_from_config(config_path)
    cfg = dict(cfg)
    for key in ("data_dir", "output_dir"):
        p = Path(cfg[key])
        if not p.is_absolute():
            p = root / p
        cfg[key] = p.resolve()
    cfg["project_root"] = root
    return cfg


CONFIG_KEYS={
    'extraction':{'min_text_chars_before_ocr','use_docling','ocr_languages','ocr_use_gpu','document_timeout_seconds','document_timeout_attempts',
                  'page_max_replacement_fraction','page_max_control_fraction','page_min_alnum_fraction',
                  'page_max_dominant_character_fraction','page_max_duplicate_line_fraction',
                  'page_compare_min_chars','page_min_native_ocr_token_dice','page_quality_render_previews',
                  'page_quality_max_previews_per_document','page_quality_preview_dpi'},
    'cleaning':{'unicode_form','repeated_line_page_ratio','repeated_line_max_chars'},
    'parsing':{'keep_unparsed_preamble','minimum_provision_chars'},
    'knowledge':{'checklist_mode','ollama_model','issue_min_score','relation_confidence_threshold','case_ontology_mode','ai_provider','ai_url','ai_model','ai_health_url','ai_timeout_seconds','ai_cache_dir','ai_max_provisions','ai_max_output_tokens','ai_context_tokens','ai_max_consecutive_failures','ai_chunk_bytes','ai_case_budget_seconds','ai_checklist_budget_seconds','ai_compact_output','ai_grounding_repair','ai_max_split_depth'},
    'retrieval':{'embedding_model','embedding_model_path','embedding_device','embedding_batch_size','embedding_chunk_size','embedding_max_length','embedding_use_fp16','bm25_method','case_knn_k','community_algorithm'},
    'neo4j':{'load_batch_size'},
}
CONFIG_KEYS['knowledge'].update({'ai_source_accounting','ai_anchor_chars','ai_accounting_window','ai_continuation_pages'})


def validate_config(cfg):
    unknown=set(cfg)-set(CONFIG_KEYS)-{'data_dir','output_dir','project_root'}
    if unknown: raise ValueError(f'Unknown config sections: {sorted(unknown)}')
    for section,allowed in CONFIG_KEYS.items():
        extra=set(cfg.get(section,{}))-allowed
        if extra: raise ValueError(f'Unused/unknown {section} config keys: {sorted(extra)}')
    knowledge=cfg.get('knowledge',{})
    if 'ai_source_accounting' in knowledge and type(knowledge['ai_source_accounting']) is not bool:
        raise ValueError('ai_source_accounting must be boolean')
    for key,low,high in [('ai_anchor_chars',64,400),('ai_accounting_window',1,4),('ai_continuation_pages',1,8)]:
        if key in knowledge and (type(knowledge[key]) is not int or not low<=knowledge[key]<=high):
            raise ValueError(f'{key} must be an integer from {low} to {high}')
