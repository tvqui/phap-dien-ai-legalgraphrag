# So sánh thống nhất

N/A = chưa đo/không tương đương, không phải điểm 0. Gold DRAFT và tập phát triển không chứng minh tổng quát hóa.

| Phương pháp | Tác vụ | OK / dự kiến | Lỗi | P@K | R@K | MRR@K | nDCG@K | Recall nhóm | AI đúng | AI đủ | ms TB | p95 ms |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| graph_on | qa | 47/47 | 0 | N/A | N/A | N/A | N/A | N/A | 0.9468 | 0.9213 | 29328.3440 | 89578.7971 |

COMPLETE chỉ là lịch inference hoàn tất; xem ai_judged_attempts/ai_judge_errors và mẫu số từng metric trong JSON/CSV để biết mức chấm QA.
Chỉ so các dòng có cùng comparison_key. Cột trích dẫn chỉ kiểm metadata; không chứng nhận lập luận đúng luật.
CI bootstrap theo câu hỏi, không coi các lần lặp là câu độc lập. Độ trễ không gồm judge, chuẩn bị chỉ mục và đo GPU sau phản hồi.
Xem paired_deltas.json, phạm vi Gold, lỗi, số câu chung và component_exposure trước khi kết luận thành phần có ích hoặc gây hại.
Nếu hardware_comparison_scope=GPU_SPEC: cùng loại GPU/VRAM/driver, cho phép khác UUID thiết bị; không khẳng định cùng GPU vật lý hoặc độ trễ cloud giống hệt. Xem run_manifest và resume_environments.jsonl.